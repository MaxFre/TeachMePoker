package ProjektTEST;




public class StartGame {		

	
	public StartGame(){
		int nbrOfPlayers = 4;		
//		new Table();
		new Dealer();
	}
	
	
	
	
	public static void main(String [] args){
		StartGame run = new StartGame();
	}

}
